let increaseButton = document.getElementById("increase");
let resetButton = document.getElementById("reset");
let decreaseButton = document.getElementById("decrease");
let numberElement = document.getElementById("number");

function increaseNumber() {
    // Parse the current value as an integer
    let currentValue = parseInt(numberElement.textContent);

    // Increment the value
    currentValue++;

    // Update the text content of the element
    numberElement.textContent = currentValue;

    if (currentValue > 0) {
        numberElement.style.color = "green"
    };
}

function decreaseNumber() {
    let currentValue = parseInt(numberElement.textContent);

    currentValue--;

    numberElement.textContent = currentValue;

    if (currentValue < 0) {
        numberElement.style.color = "red"
    };
}

function resetNumber() {
    numberElement.textContent = "0"
}

